<?php

//for plans

$token = '222ecef5f40b24c9e0cb9537e00e0f12'; 


?>